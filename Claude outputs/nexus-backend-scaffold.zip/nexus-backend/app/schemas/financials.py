"""Pydantic v2 schemas for the Financials / Policy Hub domain."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class PolicyProviderBreakdown(BaseModel):
    """Aggregated premium figures for a single third-party policy provider
    (e.g. easiPol) as seen by this tenant."""

    model_config = ConfigDict(frozen=True)

    provider_name: str
    active_policies: int = Field(ge=0)
    monthly_premium_total: float = Field(ge=0)
    lapsed_last_30_days: int = Field(ge=0)


class FinancialSummaryResponse(BaseModel):
    """Response body for `GET /api/v1/financials/summary`."""

    model_config = ConfigDict(frozen=True)

    tenant_id: str
    generated_at: datetime
    total_active_policies: int = Field(ge=0)
    total_monthly_premium_revenue: float = Field(ge=0)
    outstanding_claims_value: float = Field(ge=0)
    providers: list[PolicyProviderBreakdown]
