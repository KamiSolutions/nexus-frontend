"""Nexus Portal FastAPI application entrypoint."""

from __future__ import annotations

from fastapi import FastAPI

from app.api.v1.router import api_router
from app.core.config import settings

app = FastAPI(
    title=settings.PROJECT_NAME,
    version="0.1.0",
    description="Deathcare Operating System — unified command backend for funeral services providers.",
)

app.include_router(api_router, prefix=settings.API_V1_PREFIX)


@app.get("/health", tags=["meta"])
async def health_check() -> dict[str, str]:
    """Liveness probe — deliberately has no tenant/auth dependencies."""
    return {"status": "ok", "environment": settings.ENVIRONMENT}
