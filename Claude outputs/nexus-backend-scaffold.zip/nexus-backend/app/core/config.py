"""
Application configuration.

Centralised, environment-driven settings using pydantic-settings.
Never hardcode secrets or environment-specific values elsewhere in the codebase —
import `settings` from here instead.
"""

from functools import lru_cache
from typing import Literal

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # --- Core ---
    PROJECT_NAME: str = "Nexus Portal API"
    ENVIRONMENT: Literal["local", "staging", "production"] = "local"
    API_V1_PREFIX: str = "/api/v1"

    # --- Security / JWT ---
    JWT_SECRET_KEY: str = "CHANGE_ME_IN_ENV"  # noqa: S105 - overridden via .env in real deployments
    JWT_ALGORITHM: str = "HS256"
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES: int = 60

    # --- Multi-tenancy ---
    DEMO_TENANT_ID: str = "demo_sandbox"
    TENANT_HEADER_NAME: str = "X-Tenant-ID"

    # --- POPIA / compliance ---
    # South African POPIA requires data residency + audit logging awareness at the
    # infrastructure layer; this flag lets services short-circuit into stricter
    # logging/retention behaviour without a code change.
    STRICT_COMPLIANCE_MODE: bool = True


@lru_cache
def get_settings() -> Settings:
    """Cached settings accessor — avoids re-parsing the environment on every call."""
    return Settings()


settings = get_settings()
