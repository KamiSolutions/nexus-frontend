"""
JWT encode/decode primitives.

Kept deliberately separate from the FastAPI dependency layer (see
`app/dependencies/auth.py`) so this module can be unit-tested with zero
framework imports.
"""

from __future__ import annotations

import datetime as dt
from typing import Any

import jwt
from jwt import InvalidTokenError

from app.core.config import settings


class TokenError(Exception):
    """Raised when a JWT cannot be decoded or fails validation."""


def create_access_token(
    *,
    subject: str,
    scopes: list[str],
    tenant_id: str,
    expires_delta: dt.timedelta | None = None,
) -> str:
    """
    Issue a signed JWT for `subject` (typically a user id) carrying the
    security scopes and tenant binding needed by downstream dependencies.

    This is primarily used by the auth/login service and by tests/scripts
    that need to mint tokens without a full login round-trip.
    """
    now = dt.datetime.now(dt.timezone.utc)
    expire = now + (expires_delta or dt.timedelta(minutes=settings.JWT_ACCESS_TOKEN_EXPIRE_MINUTES))

    payload: dict[str, Any] = {
        "sub": subject,
        "scopes": scopes,
        "tenant_id": tenant_id,
        "iat": int(now.timestamp()),
        "exp": int(expire.timestamp()),
    }
    return jwt.encode(payload, settings.JWT_SECRET_KEY, algorithm=settings.JWT_ALGORITHM)


def decode_access_token(token: str) -> dict[str, Any]:
    """
    Decode and validate a JWT, raising `TokenError` on any failure
    (expired, malformed, bad signature, etc.) so callers never need to
    know about the `jwt` library's own exception hierarchy.
    """
    try:
        return jwt.decode(
            token,
            settings.JWT_SECRET_KEY,
            algorithms=[settings.JWT_ALGORITHM],
        )
    except InvalidTokenError as exc:
        raise TokenError(str(exc)) from exc
