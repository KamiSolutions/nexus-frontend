"""
Financials domain service.

Houses the async data-fetching logic used by the financials router.
Kept separate from the route module so it can be reused by, e.g., a
background worker or a webhook handler without importing FastAPI.
"""

from __future__ import annotations

import asyncio
import random
from datetime import datetime, timezone

from app.schemas.financials import FinancialSummaryResponse, PolicyProviderBreakdown
from app.schemas.tenant import TenantContext

# Providers a funeral parlour tenant might integrate with for policy data.
_KNOWN_PROVIDERS: tuple[str, ...] = ("easiPol", "Sanlam Sky", "Old Mutual", "In-House Book")


async def _fetch_provider_snapshot(tenant: TenantContext, provider_name: str) -> PolicyProviderBreakdown:
    """
    Simulates one concurrent, non-blocking call out to a third-party
    policy provider's API/webhook (e.g. easiPol) for this tenant.

    Replace the body with a real `httpx.AsyncClient` call; the
    `asyncio.sleep` stands in for network latency so `get_financial_summary`
    genuinely demonstrates concurrent I/O rather than sequential mocking.
    """
    await asyncio.sleep(random.uniform(0.05, 0.2))

    rng = random.Random(f"{tenant.tenant_id}:{provider_name}")
    return PolicyProviderBreakdown(
        provider_name=provider_name,
        active_policies=rng.randint(50, 4000),
        monthly_premium_total=round(rng.uniform(15_000, 850_000), 2),
        lapsed_last_30_days=rng.randint(0, 40),
    )


async def get_financial_summary(tenant: TenantContext) -> FinancialSummaryResponse:
    """
    Build the tenant's financial summary by fanning out to every
    configured policy provider concurrently via `asyncio.gather`, then
    aggregating the results.

    This is the pattern to follow for any endpoint that needs to combine
    several slow, independent I/O calls (DB + one or more third-party
    APIs) without serializing them.
    """
    provider_snapshots = await asyncio.gather(
        *(_fetch_provider_snapshot(tenant, provider) for provider in _KNOWN_PROVIDERS)
    )

    total_active_policies = sum(p.active_policies for p in provider_snapshots)
    total_premium_revenue = sum(p.monthly_premium_total for p in provider_snapshots)

    # Outstanding claims value would normally come from a separate claims
    # ledger query, run concurrently alongside the provider fan-out above.
    outstanding_claims_value = round(total_premium_revenue * 0.032, 2)

    return FinancialSummaryResponse(
        tenant_id=tenant.tenant_id,
        generated_at=datetime.now(timezone.utc),
        total_active_policies=total_active_policies,
        total_monthly_premium_revenue=round(total_premium_revenue, 2),
        outstanding_claims_value=outstanding_claims_value,
        providers=list(provider_snapshots),
    )
