"""Aggregates every v1 domain router behind the single `/api/v1` prefix."""

from __future__ import annotations

from fastapi import APIRouter

from app.api.v1 import financials

api_router = APIRouter()
api_router.include_router(financials.router)

# Future domain routers plug in the same way, e.g.:
# from app.api.v1 import hr, vehicles, leases, policies
# api_router.include_router(hr.router)
# api_router.include_router(vehicles.router)
