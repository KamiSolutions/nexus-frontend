"""
Financials / Policy Hub router.

Every route here requires both:
  * a resolved tenant context (`get_tenant_context`) — data isolation, and
  * the `financials:read` (or stricter) security scope — RBAC.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Security

from app.dependencies.auth import get_current_user
from app.dependencies.tenant import get_tenant_context
from app.schemas.auth import CurrentUser
from app.schemas.financials import FinancialSummaryResponse
from app.schemas.tenant import TenantContext
from app.services.financials.policy_service import get_financial_summary

router = APIRouter(prefix="/financials", tags=["financials"])


@router.get(
    "/summary",
    response_model=FinancialSummaryResponse,
    summary="Tenant-wide financial & policy summary",
)
async def read_financial_summary(
    tenant: TenantContext = Depends(get_tenant_context),
    current_user: CurrentUser = Security(get_current_user, scopes=["financials:read"]),
) -> FinancialSummaryResponse:
    """
    Aggregate premium, policy-count and outstanding-claims figures across
    every policy provider (e.g. easiPol) integrated for this tenant.

    Restricted to principals holding `financials:read` — e.g. a branch
    executive or finance officer, never a driver or mortuary attendant
    token, which would carry `vehicles:read` / `logistics:read` instead.
    """
    # current_user is available for audit logging / row-level narrowing;
    # referenced here to make that intent explicit even though this demo
    # endpoint doesn't yet write an audit trail.
    del current_user
    return await get_financial_summary(tenant)
