# Nexus Portal — FastAPI Backend Scaffold

Foundational, production-oriented scaffolding for the Nexus Portal
"Deathcare Operating System" backend. Async, multi-tenant, RBAC-scoped.

## Run it

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Then visit `http://127.0.0.1:8000/docs`.

## Try the demo endpoint (no tenant header → demo sandbox)

You'll need a bearer token with the `financials:read` scope. Mint one from
a Python shell for local testing:

```python
from app.core.security import create_access_token
print(create_access_token(subject="dev-user", scopes=["financials:read"], tenant_id="demo_sandbox"))
```

```bash
curl -H "Authorization: Bearer <token>" http://127.0.0.1:8000/api/v1/financials/summary
```

Add `-H "X-Tenant-ID: avbob_prod"` to hit the (mocked) dedicated-tenant path instead.

## Folder structure

```
app/
├── main.py                    # FastAPI app instantiation, router mounting
├── core/
│   ├── config.py              # pydantic-settings, env-driven
│   └── security.py            # JWT encode/decode (framework-agnostic)
├── dependencies/
│   ├── tenant.py               # get_tenant_context — multi-tenant isolation
│   └── auth.py                 # get_current_user — JWT + SecurityScopes RBAC
├── schemas/
│   ├── tenant.py, auth.py, financials.py   # Pydantic v2 request/response models
├── api/v1/
│   ├── router.py               # aggregates domain routers under /api/v1
│   └── financials.py           # GET /financials/summary
└── services/
    ├── financials/policy_service.py   # async aggregation across policy providers
    ├── hr/                     # HR & payroll module — next to scaffold
    └── logistics/              # fleet / mortuary logistics module — next to scaffold
```

## Extending to HR and Logistics

Follow the exact same three-file pattern used for financials:
1. `schemas/hr.py` / `schemas/logistics.py` — Pydantic v2 models.
2. `services/hr/*` / `services/logistics/*` — async business logic, no FastAPI imports.
3. `api/v1/hr.py` / `api/v1/vehicles.py` — thin routers wiring `get_tenant_context` +
   `Security(get_current_user, scopes=[...])` to the service layer, then
   registered in `api/v1/router.py`.

Suggested scopes to mirror the frontend RBAC groups already scaffolded there:
`financials:read`, `financials:write`, `hr:read`, `hr:write`, `vehicles:read`,
`vehicles:write`, `policies:read`, `policies:write`, `admin:*`.

## Multi-tenancy notes

- `get_tenant_context` resolves `X-Tenant-ID` against `_TENANT_REGISTRY` in
  `dependencies/tenant.py`. Swap that in-memory dict for a real async
  lookup (control-plane Postgres table, or a dedicated tenant-directory
  service) — no caller changes required, since routes only ever depend on
  the resolved `TenantContext`.
- `deployment_mode` on `TenantContext` distinguishes `"shared"` (row/schema
  isolated multi-tenant SaaS, for small independent parlours) from
  `"dedicated"` (single-tenant deployment, for AVBOB/Nyaradzo-scale
  networks) so a service layer can branch on it if the two shapes ever
  need materially different query strategies.

## Compliance

`STRICT_COMPLIANCE_MODE` in `core/config.py` is a placeholder switch for
POPIA-driven behaviour (audit logging, data residency checks, retention
enforcement) — wire actual middleware/logging behind it as those
requirements get specified.
